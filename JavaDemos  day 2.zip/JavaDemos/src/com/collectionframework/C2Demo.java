package com.collectionframework;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class C2Demo {

	public static void main(String[] args) {
		List<List<String>> nestedList = Arrays.asList(Arrays.asList("one:one"),Arrays.asList("two:one", "two:two", "two:three"),
				Arrays.asList("three:one", "three:two", "three:three", "three:four"));
		List<String> ls = flattenListOfListsImperatively(nestedList);

	}

	private static List<String> flattenListOfListsImperatively(List<List<String>> nestedList) {
		List<String> ls = new ArrayList<>();
		return null;
	}

	public List<String> static flattenListOfListsImperat(List<List<String>> nestedList) {
		
		nestedList.forEach(ls.addAll());
		return ls;
	}
}
