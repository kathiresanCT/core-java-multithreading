package com.collectionframework;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class C1Demo {

	public static void main(String[] args) {
	Collection col=new HashSet();
	col.add(2);
	col.add(3);
	col.add(12);
	System.out.println(col);
	//	 List li=new ArrayList();
		 LinkedList li=new LinkedList(col);
		 li.add(10);
		 li.add(20);
		/* Iterator i=li.iterator();
		 li.add(90);//concurrent modification excep
		 while(i.hasNext()) {
			 System.out.println(i.next());
		 }*/
		li.addFirst(101);	
	/*	System.out.println(li);
		ListIterator ll=li.listIterator();
		while(ll.hasPrevious())
		{
			System.out.println(ll.previous());
		}
		Collections.reverse(li);
		System.out.println(li);
		Collections.shuffle(li);
		System.out.println(li);
		Collections.sort(li);
		System.out.println(li);
		Collections.synchronizedList(li);
	*/	Set<String> matchingStrings = new HashSet(Arrays.asList(2, "10", "c", "d", "e", "f"));
		 
		Iterator<String> it = li.iterator();
		while (it.hasNext()) {
		    if (matchingStrings.contains(it.next())) {
		        it.remove();
		    }
		}
		//System.out.println(li);
		List<String> list1 = Arrays.asList("1", "2", "3", "4");
		List<String> list2 = Arrays.asList("1", "2", "3", "4");
		List<String> list3 = Arrays.asList("1", "2", "4", "3");
		System.out.println(list1.equals(list2));
		System.out.println(list1+" "+list2);
		System.out.println(list1.equals(list3));
		System.out.println(list1+" "+list3);
	}

}
