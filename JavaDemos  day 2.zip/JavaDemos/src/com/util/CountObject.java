package com.util;

public class CountObject {

	//counter variable
	
	static int count=0;
	public CountObject() {
		//incr the counter
		++count;
	}
	
	public static void main(String[] args) {
		CountObject ob1=new CountObject();
		CountObject ob2=new CountObject();
		CountObject ob3=new CountObject();
		//print count var
		System.out.println("no of objects craeted "+count);
	}

}
