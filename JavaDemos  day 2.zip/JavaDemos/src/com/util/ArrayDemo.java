package com.util;

import abstractDemo.*;

public class ArrayDemo {

	public static void main(String[] args) {
	//	Emp emp[]=new Emp[5]; 
		//emp[0]=new Emp();
		//emp[1]=new Emp();
		
		
		float a[]=new float[4];
		a[0]=2;
		a[3]=9;
		System.out.println("before "+a[3]+" "+a[2]);
		a=new float[8];
		
	System.out.println(a[3]+" "+a[2]);	
	}

	
}
