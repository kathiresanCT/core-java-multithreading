package com.util;

public class Human extends Primate{
//eat,walk
	static {
		System.out.println("in 1");
	}
	
	static {
		System.out.println("in 2");
	}
public void think() {
	System.out.println("think");
}
//overriding
public void walk() {
	System.out.println("walks with 2 legs");
}
}
