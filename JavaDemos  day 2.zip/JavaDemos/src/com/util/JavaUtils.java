package com.util;

public class JavaUtils {
	//counter variable
	
	public JavaUtils(int a, int b) {
		System.out.println("in arg constructor");
	}

	public JavaUtils() {
		// TODO Auto-generated constructor stub
	}

	int a = 1;
	static int b = 2;

	public static void main(String[] args) {

		// System.out.println("addition result is "+9*9);

		JavaUtils j1 = new JavaUtils();
		// j1.display();
		JavaUtils j2 = new JavaUtils();
		JavaUtils j3 = new JavaUtils();

		System.out.println(++j1.a);
		System.out.println(++j2.a);
		System.out.println(++j3.a);

		System.out.println(++j1.b);
		System.out.println(++j2.b);
		System.out.println(++j3.b);
		System.out.println(j1.b);
//		System.out.println(j1);// ?
//		System.out.println(j1.toString());// ?
//		System.out.println(j1.hashCode());
//		
	}

	public String toString() {
		// return getClass().getName()+"@"+Integer.toHexString(hashCode());
		return "hello " + hashCode();
	}

}
