package com.util;

public class Primate {
	static {
		System.out.println("in primate - statoc block");
	}
	public void eat() {
		System.out.println("eating");
	}

	public void walk() {
		System.out.println("walk with 2 legs & 2 hands ");
	}
}
