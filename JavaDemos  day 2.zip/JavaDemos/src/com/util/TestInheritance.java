package com.util;
import java.util.Scanner;

public class TestInheritance {

	public static void main(String[] args) {
		TestInheritance t=new TestInheritance();
		
//		Human h=new Human();
//		h.eat();
//		h.walk();
//		h.think();
	//	Scanner scan=new Scanner(System.in);
		/*System.out.println("plese enter ur name");
		String name=scan.nextLine();
		System.out.println("plese enter ur surname");
		String surname=scan.next();
		System.out.println("name :: "+name+" surname :: "+surname);*/
		//Scanner scan=new Scanner("hi - hello hehhhee- how are - you").useDelimiter(" - ");
		Scanner scan=new Scanner("hi - hello -hehhhee how are - you").useDelimiter("h");
		//System.out.println(scan.next().length());
		//System.out.println(scan.next());
		while(scan.hasNext()) {
			System.out.println(scan.next());
		}
	}

}



