package com.in;

 class Employee {
//private default protected public
	int empId=01;
	private String empName="default";
	public static String  course="java";
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String name) {
		empName = name;
	}
}
 
public class Test{
	public static void main(String[] args) {
		Employee emp=new Employee();
			System.out.println(emp.empId);
		//	System.out.println(emp.empName);
			System.out.println(emp.getEmpName());
			emp.empId=9000;
			emp.setEmpName("AJAY");
			System.out.println("new name "+emp.getEmpName());
			
	}
}




