package abstractDemo;

import java.util.ArrayList;
import java.util.List;

public class CollectionDemo2 {
	
	public static void main(String... ar) { 
		
	List empList1=new ArrayList();
	List<Admin> empList=new ArrayList();
	List<Admin> empList2=new ArrayList<Admin>();
	//in java 7
	//List<Admin> empList2=new ArrayList<>();
	//
	Admin admin1=new Admin(1001,"ajay");
	Admin admin2=new Admin(1002,"nakul");
	Admin admin3=new Admin(1003,"tharun");
	//empList.add(new Manager());
	empList.add(admin1);
	
	empList.add(admin2);
	
	empList.add(admin3);
	//modifying the files
	//empList.add(new Manager());
	empList.add(admin1);
	
	System.out.println(empList);
	}

}

class Admin {
	private int id;
	private String name;

	public Admin(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Admin [id=" + id + ", name=" + name + "]";
	}
	
}

class Manager {
	private int mId;
	private String mName;

	public int getmId() {
		return mId;
	}

	public void setmId(int mId) {
		this.mId = mId;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

}