package abstractDemo;

public class TestTemplate {

	public static void main(String[] args) {
		TemplateClass<Integer> t=new TemplateClass();
		Integer i=t.display(10);
		System.out.println(i.intValue());
	//	t.display("hello");

	}

}
