package abstractDemo;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class CollectionDemo {

	public static void main(String[] args) {
	//List list=new ArrayList();
		List list=new LinkedList();
		list.add(new Emp());
		list.add(new Animal());
		list.add(new Emp());
		Iterator it=list.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
			it.remove();
		}
		System.out.println(list.isEmpty());
		/*for(Object o:list) {
			if(o instanceof Emp) {
			Emp e=(Emp)o;
			e.display();
			}
			else {
			Animal a=(Animal)o;
			a.sounds();
			}
		}*/
		
	/*list.add(10);//implicit conversion-autoboxing
	list.add(10);
	list.add(new Integer(20));
	list.add(30);
	list.add('c');
	list.add("hello");
	list.add(10.6f);
	System.out.println(list);
	list.remove(2);
	System.out.println(list);
//	list.clear();
	System.out.println(list.isEmpty());
	System.out.println(list.contains(10));
	for(Object o:list) {
		System.out.println(o);
	}
	}
*/
	}
}
 class Emp{
	
	public void display() {
		System.out.println("display");
	}
	
}
class Animal{
	
	public void sounds() {
		System.out.println("sound");
	}
}