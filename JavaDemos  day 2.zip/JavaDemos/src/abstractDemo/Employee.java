package abstractDemo;

public abstract class Employee {
	int id;
	String name;
	
	
	public Employee() {
		System.out.println("in emp constr");
	}

	public Employee(int d, String name) {
		this.id = d;
		this.name = name;
	}

	public void display() {
		System.out.println("print...");
	}

	public abstract void work();

}
