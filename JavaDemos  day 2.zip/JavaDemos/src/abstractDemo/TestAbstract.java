package abstractDemo;

public class TestAbstract {

	public static void main(String[] args) {

		Employee emp=null;//new Employee(10,"ajay"); 
		//reference
		emp=new Manager1(1001,"ajay");
		System.out.println(emp.id+""+emp.name);
	}

}
