package abstractDemo;

public class TemplateClass<T> {

	T a;
	public T display(T value) {
		//System.out.println(value);
		this.a=value;
		return a;
	}
}
