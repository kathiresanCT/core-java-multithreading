package abstractDemo;

public class Manager1 extends Employee{
	//assoc
	//compos - has a 
	//aggregation
	public Manager1(int id,String st) {
		super(id, st);
	}
	//work display
	@Override
	public void work() {
		// TODO Auto-generated method stub
		
	}

	

}
