package com.in;

import java.util.Scanner;

public class TestEncapsulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("addition \n result is :: "+(9+9));
		Scanner scan=new Scanner(System.in);
	//	Scanner scan=new Scanner("hi hello-how are-you");
		//scan.useDelimiter("-");
	//	scan.useDelimiter("h");
		System.out.println("enter ur first name");
			String name=scan.next();
		System.out.println(name);
		System.out.println("enter ur last name");
		String lName=scan.nextLine();
		System.out.println(lName);
//		while(scan.hasNext()) {
//			System.out.println(scan.next());
//		}
		long i=123456789L;
		int o=9;
	}
	public void display() {
		
		return ;
	}

}
