/*package com.ct;

public class Sample {

	public static void main(String[] args) {
		Student st=new Student();
		//System.out.println(st.studId);
		System.out.println(st.studName);
		System.out.println("old id "+st.getStudId());
		System.exit(0);
		st.setStudId(1000);
		System.out.println("new id "+st.getStudId());
	
	
	Sub ob=new Sub();
	ob.display();
	
	}

}
*/