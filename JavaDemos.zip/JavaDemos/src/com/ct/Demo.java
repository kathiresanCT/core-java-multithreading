/*package com.ct;

public class Demo {

//	public void display() {
//		System.out.println("in display");
//	}
}

class Sub extends Demo
{
	//display()
	@Override
	public void display() {
		System.out.println("in display -in sub");
	}
	
}*/