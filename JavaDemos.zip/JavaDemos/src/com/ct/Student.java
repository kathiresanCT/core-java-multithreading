package com.ct;

public class Student {
//private default  protected  public
	private int studId=90;
	String studName="hello";
	public int getStudId() {
		return studId;
	}
	public void setStudId(int id) {
		this.studId = id;
	}
}
