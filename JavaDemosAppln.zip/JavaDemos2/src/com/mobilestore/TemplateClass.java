package com.mobilestore;

public class TemplateClass<T> {

	T value;
	public T get(T value) {
		this.value=value;
		return this.value;
	}
}
