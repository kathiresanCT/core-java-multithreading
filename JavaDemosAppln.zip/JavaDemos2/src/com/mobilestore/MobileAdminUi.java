package com.mobilestore;

import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MobileAdminUi {
	List mobileList=new ArrayList<>();
	
	public MobileAdminUi() {
	Mobile m1=new Mobile(1000, "samsung", 8000);
	Mobile m2=new Mobile(999, "redmi", 8000);
	mobileList.add(m1);
	mobileList.add(m2);
	}
	
	public List getMobileList() {
		return mobileList;
	}
	public void setMobileList(List mobileList) {
		this.mobileList = mobileList;
	}
	
	public static void main(String[] args) {
		
		System.out.println("Mobile Store");
		System.out.println("1. add mobile");
		System.out.println("2. delete mobile");
		System.out.println("3. update mobile");
		System.out.println("4. view all mobile");
		System.out.println("please enter any option");
		Scanner scan = new Scanner(System.in);
		switch (scan.nextInt()) {
		case 1:
			MobileAdminUi ob =new MobileAdminUi();
			
			//create method to get mobile info
			Mobile mobile=new Mobile(1001,"HTC",4567);
			ob.addMobile(mobile);
			break;
		case 2:

			break;
		case 3:
			
			break;
		case 4:
			
			break;		
		default:
				break;
		}

	}
	public void addMobile(Mobile mobile) {
		//logic to store in collection
		getMobileList().add(mobile);	
		System.out.println("its added :: "+getMobileList());
	}
}
