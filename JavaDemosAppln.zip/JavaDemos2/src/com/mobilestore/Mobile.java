package com.mobilestore;

public class Mobile {

	private int mobId;
	private String mobName;
	private float price;
	public int getMobId() {
		return mobId;
	}
	public void setMobId(int mobId) {
		this.mobId = mobId;
	}
	public String getMobName() {
		return mobName;
	}
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Mobile(int mobId, String mobName, float price) {
		super();
		this.mobId = mobId;
		this.mobName = mobName;
		this.price = price;
	}
	
	public Mobile() {
		// TODO Auto-generated constructor stub
	}
}
