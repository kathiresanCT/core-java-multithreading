package com.mobilestore;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SetDemo {

	public static void main(String[] args) {
	//	List t=Arrays.asList(1,2,4,5,5,5,56);
		//Set s=new HashSet(t);
		Set<Integer> s=new HashSet();
	s.add(10);
	s.add(10);
//	s.add('f');
	//s.add(10.5f);
	//	System.out.println(s);
		/*s.add(new Emp());
		s.add(new Emp());
		s.add(null);
		s.add(null);
		System.out.println(s.size());*/
	Set<Integer> ob=new HashSet<>();
	
	TemplateClass<String> t=new TemplateClass<>();
	String h=t.get("hello");
	System.out.println(h);
	//iterator, enumeration
	//listIterator
	//for & iterator - difference
	//comparable & comparator
	}

}
class Emp{}

