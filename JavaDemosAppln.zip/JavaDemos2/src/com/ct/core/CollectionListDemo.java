package com.ct.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CollectionListDemo {

	public static void main(String[] args) {
		//is a - inheritance
		//has a - association - composition & aggregation
		List l=null;//insertion order
		l=new ArrayList();	
		l.add("hi");
		l.add("hi");
		l.add(4.5f);
		l.add(new Float(4.5f));
		l.add(456);//autoboxing
		Integer i=new Integer(456);
		l.add(i);//boxing
		l.add('c');
		l.add(new Emp());
		l.add(new Emp());
		System.out.println("list conatins :: "+l);
	//	System.out.println(i.intValue()); //unboxing
		
		System.out.println(l.get(0));
		l.add(1, 90000);
		System.out.println(l);
		l.set(1, 8999);
		System.out.println(l);
		
		l.remove(4);
		System.out.println(l);
	//	l.remove(new Integer(456));
	//	l.remove(456);
	//	System.out.println(l);
		//l.clear();
		System.out.println(l);
		System.out.println(l==null);
		System.out.println(l.isEmpty()?"list is empty":"list value is ::"+l);
		System.out.println(l.contains(456));
		
		ArrayList list=new ArrayList();
		list.add(0);
		list.add(null);
		list.add(null);
		list.add(null);
		list.add(0);
		list.add(00);
		l.add(list);
		System.out.println(l);
		
		List intObj=Arrays.asList(10,2,3,4,5,6);
		
		l.add(intObj);
		System.out.println(l);
		Object o=l.get(9);
		List newList=(ArrayList)o;
		System.out.println(newList.remove(3));
		System.out.println(newList);
	}

}



class Emp{
	
}
