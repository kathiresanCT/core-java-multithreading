package com.ct.core;

import java.util.Arrays;
import java.util.List;

public class IterationCollection {

	public static void main(String[] args) {
		
		List on=Arrays.asList(1,2,3,42,3,455,9.4f);
		//for each
		//iterator - Iterator(base),ListIterator(sub)
		//for(dest:source)
		//src- collection or array
		//dest - hold one value from the collection or array
		
		/*for(Object h:on) {
			System.out.println(h);
		}*/
		for(Object h:on) {
			Integer obb=(Integer)h;
			System.out.println(obb);
		}
	}

}
