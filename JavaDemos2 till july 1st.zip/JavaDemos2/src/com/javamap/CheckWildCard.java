package com.javamap;

import java.util.ArrayList;

public class CheckWildCard {
	static void method(ArrayList<? super A> ob) {
		System.out.println(ob);
	}
	public static void main(String[] args) {
		ArrayList<? extends A> on=new ArrayList();
		ArrayList on1=new ArrayList();
		on1.add(new D());
		on1.add(new D());
		on1.add(new A());
		on1.add(new B());
		method(on1);
	}}
class A extends D{}
class B extends A{}
class C extends A{}
class D {}