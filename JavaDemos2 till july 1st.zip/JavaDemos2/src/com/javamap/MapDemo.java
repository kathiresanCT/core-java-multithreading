package com.javamap;

import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;
import java.util.TreeSet;

public class MapDemo {
	public static void main(String[] args) {
		
		/*TreeSet t=new TreeSet();
		t.add("hello");
		t.add("Alphabet");
		t.add("@");
		t.add("alphabet");
		t.add("Bore");
		t.add("bore");
		t.add("aLphabet");
		t.add("bOre");		
		t.add("AlPhabet");*/
		
		
	//	t.add("11");
	/*	t.add(10);
		t.add(10);
		t.add(23);
		t.add(1);
		t.add(4);
	*/	//t.add(null);//till java 6, from j7 - NPE
	//	System.out.println(t);
		/*		Properties p=new Properties();
		p=System.getProperties();
		System.out.println(p);
		System.out.println(p.getProperty("sun.arch.data.model"));
		*/
		// Map m=new HashMap();
		/*Map<String, String> m = new Hashtable();
		m.put("key", "value");
		m.put("key", "value");
		m.put("key1", "value2");
		m.put("key2", "value3");*/
		// m.put(null, "hari");
		// m.put(null, "ajay");
	//	System.out.println(m);
		//m.put("key", "new value");
		//System.out.println(m);
		// m.put(34, "value3");
		// m.put(3.4f, 34);
		// m.put('c', "value3");
		// m.put('e', null);
		// m.put('d', null);
	//	System.out.println(m);
		/*
		 * Set keys=m.keySet(); System.out.println(keys); Collection valueColl=
		 * m.values(); System.out.println(valueColl); Set mapeq=m.entrySet();
		 * System.out.println(mapeq); for(Object o:mapeq) { System.out.println(o); //
		 * String elem=(String)o;// excep // System.out.println(elem instanceof String);
		 * //java.util.HashMap$Node Map.Entry oo=(Map.Entry)o;
		 * System.out.println("converted "+oo.getKey());
		 * System.out.println("converted "+oo.getValue()); }
		 */
	}
}
