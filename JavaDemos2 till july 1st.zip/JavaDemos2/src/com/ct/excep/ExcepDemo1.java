package com.ct.excep;

public class ExcepDemo1 {

	public static void main(String[] args) {
		try {
			System.out.println("in main ");
			System.out.println(new ExcepDemo1().m1());
			System.out.println("in try end");
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	String m1() {
		return m2();
	}

	String m2() {
		return m3();
	}

	String m3() {
		System.exit(1);
		return 9 / 0 + "hello";

	}
}
