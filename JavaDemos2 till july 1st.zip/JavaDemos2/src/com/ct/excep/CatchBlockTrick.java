package com.ct.excep;

import java.io.IOException;

public class CatchBlockTrick {
	public static void start() throws IOException, RuntimeException{
		System.out.println(Runtime.getRuntime().availableProcessors());
	    throw new RuntimeException("Not able to Start");
	 }

	 public static void main(String args[]) {
	    try {
	          start();
	    } catch (Exception ex) {
	            ex.printStackTrace();
	    }
	    /*catch (RuntimeException re) {
	            re.printStackTrace();
	    }*/
	 }
}
