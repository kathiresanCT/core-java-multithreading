package com.ct.excep;

public class Classrelated {
	public static void main(String...e) {
			try 
	        { 
	            Class.forName("bangalore"); 
	        } 
	        catch (ClassNotFoundException ex) 
	        { 
	            ex.printStackTrace(); 
	        } 
	}
}
