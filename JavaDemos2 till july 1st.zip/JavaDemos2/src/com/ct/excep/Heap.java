package com.ct.excep;

import java.util.ArrayList;
import java.util.List; 

public class Heap { 
    static List<String> list = new ArrayList<String>(); 
  
public static void main(String args[]) throws Exception 
    { 
        Integer[] array = new Integer[100000 * 10000]; 
    } 
} 