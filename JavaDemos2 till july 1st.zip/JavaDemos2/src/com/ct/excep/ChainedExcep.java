package com.ct.excep;

public class ChainedExcep {

	static void methodCause() {
		// create an exception
		NullPointerException e = new NullPointerException("thrown as null pointer");
		// add a cause
		e.initCause(new ArithmeticException("caused by arithmetic"));
		throw e;
	}

	public static void main(String[] args) {
		try {
			methodCause();
		} catch (NullPointerException e) {
			// display top level exception
			System.out.println("Caught: " + e);
			// display cause exception
			System.out.println("Original cause: " + e.getCause());
		}
	}
}
