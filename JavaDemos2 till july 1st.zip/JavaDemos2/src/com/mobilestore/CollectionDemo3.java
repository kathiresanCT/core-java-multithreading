package com.mobilestore;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class CollectionDemo3 {

	public static void main(String[] args) {
	//	List<Integer> t=Arrays.asList(1,2,3,5,5,66,56);
		List t=new ArrayList();
		t.add(10); t.add(30);
		
		Iterator iter= t.iterator();
		//t.add(2345);
		//concurrentModification - when u iterate
		//ConcurrentAccessException - copy - collections.copy
		while(iter.hasNext())
		{
			System.out.println(iter.next());
			
		//	if(iter.next().equals(10)) {
			iter.remove();
			//}
			}
		System.out.println(t);
		
	}

}
