package com.mobilestore;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class MapDemo {

	public static void main(String[] args) {
		//Map.Entry<K, V>
		Map m=new Hashtable(); //HashMap();
		//m.put(null,1); --NPE
		//m.put("one",null); --NPE
		m.put("one",1);
		m.put("one",1);
		m.put("two",1);
		m.put("one",4453);
		
		System.out.println(m);
		System.out.println(m.keySet());
		System.out.println(m.values());
		System.out.println(m.entrySet());
	}

}
