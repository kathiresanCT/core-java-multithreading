package com.mobilestore;

// multiple & multi catch
// custom exception



public class StringOper {

	public static void main(String[] args) {
		
		int a=90;
		int b=10;
		int c=0;
		StringOper o=null;
		try {
			o.clone();
		c=a/b;//creates an objof arith excep & throw
		System.out.println("result : "+c);
		}
		catch(Exception e) {
			System.out.println(e instanceof ArithmeticException);
			System.out.println("exception occured :: "+e.getMessage());
		}
		
		System.out.println("normal flow of program...");
		
		/*String s=new String("hello");//2 object
		String s2=new String("hello");//2 object
		String s1="hello"; // pointing to SCP
		System.out.println(s1.hashCode()+" "+s2.hashCode()+" "+s.hashCode());
		String s4=" 90";
		System.out.println(Integer.parseInt(s4));
		// exception,errors
		//checked(compile-time) , unchecked(runtime)
		// Throwable
*/		
	}

}
