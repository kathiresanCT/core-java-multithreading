package com.mobilestore;

import java.util.Set;
import java.util.TreeSet;
//string --- == checks the address
//equals - content

//obj - equals - reference

public class LiStEquality {

	public static void main(String[] args) {
		Set s=new TreeSet();
	//	s.add(1);
		s.add(null);//after java 7 throws NPE
		s.add(10);
		//s.add(20.5);
		s.add(30);
		s.add(10);
		System.out.println(s);
/*		List<String> list1 = Arrays.asList("1", "2", "3", "4");
		List<String> list2 = Arrays.asList("1", "2", "3", "4");
		List<String> list3 = Arrays.asList("1", "2", "4", "3");
		
		System.out.println(list1.hashCode());
		System.out.println(list2.hashCode());
		System.out.println(list1.equals(list2));
		System.out.println(list1.equals(list3));
		System.out.println(list1==list2);
		System.out.println(list1==list3);

		List l3=new ArrayList();
		
		l3.add(list1);
		l3.add(list2);
		System.out.println(l3);*/
	}

}
